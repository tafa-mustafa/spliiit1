<div>

        <input wire:model="quantity"  type="number" min="0 wire:change="updateCart">

</div>
