@extends('layouts.front')

@section('content')
<div class="container text-center">

<h2>
    This is contact page
</h2>

<p class="mb-4">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus quis tempore ut fuga numquam est, placeat neque?
    Labore commodi consequuntur quae minima dolorum rerum voluptate. Laudantium eligendi voluptatibus officiis labore!
</p>

</div>

@endsection


